class AvailabilityWaitTask extends Thread {
    private final LibrarySystem library;
    private final String bookId;

    public AvailabilityWaitTask(LibrarySystem library, String bookId) {
        super("ReservationWaitTask");
        this.library = library;
        this.bookId = bookId;
    }

    @Override
    public void run() {
        try {
            Dashboard.showInfo(getName() + " waiting for " + bookId + " using wait()/notifyAll().");
            library.getInventory().waitForAvailability(bookId);
            Dashboard.showSuccess(getName() + " resumed: " + bookId + " is available.");
        } catch (Exception e) {
            Dashboard.showError(getName() + " stopped: " + e.getMessage());
        }
    }
}
