class DueDateNotification extends Notification {
    public DueDateNotification(String memberId, String message) {
        super(memberId, message);
    }

    @Override
    public void send() {
        Dashboard.showWarning("[DUE-DATE] Member " + memberId + ": " + message);
    }
}
