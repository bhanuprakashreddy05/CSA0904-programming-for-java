class OverdueNotification extends Notification {
    public OverdueNotification(String memberId, String message) {
        super(memberId, message);
    }

    @Override
    public void send() {
        Dashboard.showError("[OVERDUE] Member " + memberId + ": " + message);
    }
}
