import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final LibrarySystem library = new LibrarySystem();

    public static void main(String[] args) {
        loadSampleData();
        Dashboard.showHeader("SMART LIBRARY MANAGEMENT SYSTEM");
        boolean running = true;
        while (running) {
            printMenu();
            try {
                int choice = Integer.parseInt(scanner.nextLine().trim());
                switch (choice) {
                    case 1 -> registerMember();
                    case 2 -> addBook();
                    case 3 -> library.getInventory().printInventory();
                    case 4 -> searchBooks();
                    case 5 -> updateBook();
                    case 6 -> issueBook();
                    case 7 -> returnBook();
                    case 8 -> reserveBook();
                    case 9 -> cancelReservation();
                    case 10 -> library.printMembers();
                    case 11 -> library.printLoans();
                    case 12 -> sendNotifications();
                    case 13 -> concurrentDemo();
                    case 14 -> utilizationReport();
                    case 15 -> reservationQueue();
                    case 0 -> running = false;
                    default -> Dashboard.showWarning("Invalid menu choice selected.");
                }
            } catch (NumberFormatException e) {
                Dashboard.showWarning("Invalid input: enter a numeric menu option.");
            } catch (Exception e) {
                Dashboard.showError("Operation failed: " + e.getMessage());
            }
        }
        Dashboard.showInfo("Thank you for using Smart Library Management System.");
    }

    private static void printMenu() {
        Dashboard.showMenu("LIBRARY DASHBOARD", List.of(
                "1. Register Member",
                "2. Add Book",
                "3. Display Inventory",
                "4. Search Books",
                "5. Update Book",
                "6. Issue Book",
                "7. Return Book / Calculate Fine",
                "8. Reserve Unavailable Book",
                "9. Cancel Reservation",
                "10. Display Members",
                "11. Circulation Report",
                "12. Due / Overdue Notifications",
                "13. Multithreading Issue Demo",
                "14. Inventory Utilization Report",
                "15. Reservation Queue",
                "0. Exit"
        ));
        System.out.print("Enter choice: ");
    }

    private static void registerMember() throws Exception {
        String id = Dashboard.prompt("Member ID", scanner);
        String name = Dashboard.prompt("Name", scanner);
        String email = Dashboard.prompt("Email", scanner);
        int type = Integer.parseInt(Dashboard.prompt("Type (1-Student, 2-Faculty)", scanner));
        Member member = type == 1 ? new StudentMember(id, name, email) : new FacultyMember(id, name, email);
        library.registerMember(member);
        Dashboard.showSuccess("Member registered: " + member.getMemberId() + " (" + member.getMembershipType() + ")");
    }

    private static void addBook() throws Exception {
        String id = Dashboard.prompt("Book ID", scanner);
        String title = Dashboard.prompt("Title", scanner);
        String author = Dashboard.prompt("Author", scanner);
        String category = Dashboard.prompt("Category", scanner);
        int copies = Integer.parseInt(Dashboard.prompt("Total copies", scanner));
        if (copies <= 0) throw new InvalidInputException("Copies must be positive.");
        library.getInventory().addBook(new Book(id, title, author, category, copies));
        Dashboard.showSuccess("Book added successfully.");
    }

    private static void searchBooks() {
        String keyword = Dashboard.prompt("Enter title/author/category/ID keyword", scanner);
        List<Book> books = library.searchBooks(keyword);
        if (books.isEmpty()) {
            Dashboard.showInfo("No matching books found.");
        } else {
            Dashboard.showTable("SEARCH RESULTS", books.stream().map(Book::toString).toList());
        }
    }

    private static void updateBook() throws Exception {
        String id = Dashboard.prompt("Book ID", scanner);
        String title = Dashboard.prompt("New title", scanner);
        String author = Dashboard.prompt("New author", scanner);
        String category = Dashboard.prompt("New category", scanner);
        library.updateBook(id, title, author, category);
        Dashboard.showSuccess("Book record updated.");
    }

    private static void issueBook() throws Exception {
        String memberId = Dashboard.prompt("Member ID", scanner);
        String bookId = Dashboard.prompt("Book ID", scanner);
        Loan loan = library.issueBook(memberId, bookId);
        Dashboard.showSuccess("Book issued successfully. Due date: " + loan.getDueDate());
    }

    private static void returnBook() throws Exception {
        String memberId = Dashboard.prompt("Member ID", scanner);
        String bookId = Dashboard.prompt("Book ID", scanner);
        LocalDate date = LocalDate.parse(Dashboard.prompt("Return date (YYYY-MM-DD)", scanner));
        double fine = library.returnBook(memberId, bookId, date);
        Dashboard.showSuccess("Book returned successfully. Fine = Rs. " + String.format("%.2f", fine));
    }

    private static void reserveBook() throws Exception {
        String memberId = Dashboard.prompt("Member ID", scanner);
        String bookId = Dashboard.prompt("Book ID", scanner);
        library.reserveBook(memberId, bookId);
        Dashboard.showSuccess("Reservation added to the waitlist.");
    }

    private static void cancelReservation() throws Exception {
        String memberId = Dashboard.prompt("Member ID", scanner);
        String bookId = Dashboard.prompt("Book ID", scanner);
        library.cancelReservation(memberId, bookId);
        Dashboard.showSuccess("Reservation cancelled.");
    }

    private static void sendNotifications() throws InterruptedException {
        Dashboard.showInfo("Checking member due date and overdue notifications...");
        OverdueNotificationTask task = new OverdueNotificationTask(library, LocalDate.now().plusDays(11));
        task.start();
        task.join();
    }

    private static void concurrentDemo() throws Exception {
        Dashboard.showInfo("Running concurrent issue test on B102 (1 copy)...");
        ConcurrentIssueTask t1 = new ConcurrentIssueTask(library, "M001", "B102", Thread.MAX_PRIORITY);
        ConcurrentIssueTask t2 = new ConcurrentIssueTask(library, "M002", "B102", Thread.NORM_PRIORITY);
        t1.start(); t2.start();
        t1.join(); t2.join();
        AvailabilityWaitTask waiter = new AvailabilityWaitTask(library, "B102");
        waiter.start();
        Thread.sleep(500);
        Loan active = library.findActiveLoanForBook("B102");
        if (active != null) {
            library.returnBook(active.getMemberId(), active.getBookId(), LocalDate.now());
            Dashboard.showInfo("Main thread returned B102; notifyAll() released the waiting task.");
        }
        waiter.join();
        Dashboard.showSuccess("Concurrent issue test completed. Inventory remains consistent.");
    }

    private static void utilizationReport() { library.printUtilizationReport(); }

    private static void reservationQueue() {
        String bookId = Dashboard.prompt("Book ID", scanner);
        library.printReservationQueue(bookId);
    }

    private static void loadSampleData() {
        try {
            library.registerMember(new StudentMember("M001", "Aarav", "aarav@example.com"));
            library.registerMember(new FacultyMember("M002", "Dr. Meera", "meera@example.com"));
            library.registerMember(new StudentMember("M003", "Riya", "riya@example.com"));
            library.getInventory().addBook(new Book("B101", "Java Programming", "Herbert Schildt", "Programming", 3));
            library.getInventory().addBook(new Book("B102", "Data Structures", "Mark Allen Weiss", "Computer Science", 1));
            library.getInventory().addBook(new Book("B103", "Database Systems", "Raghu Ramakrishnan", "Database", 2));
            library.getInventory().addBook(new Book("B104", "Computer Networks", "Andrew S. Tanenbaum", "Networking", 2));
            library.getInventory().addBook(new Book("B105", "Operating Systems", "Silberschatz", "Systems", 2));
        } catch (Exception e) {
            Dashboard.showError("Sample data loading error: " + e.getMessage());
        }
    }
}
