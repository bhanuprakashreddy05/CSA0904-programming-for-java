import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Dashboard {
    public static final int WIDTH = 88;

    public static void showHeader(String title) {
        System.out.println();
        System.out.println(border());
        System.out.printf("| %-" + (WIDTH - 2) + "s |%n", centerText(title, WIDTH - 2));
        System.out.println(border());
    }

    public static void showMenu(String title, List<String> items) {
        List<String> content = new ArrayList<>();
        content.add(title);
        content.addAll(items);
        showPanel("MAIN NAVIGATION", content);
    }

    public static void showPanel(String title, List<String> lines) {
        System.out.println();
        System.out.println(border());
        System.out.printf("| %-" + (WIDTH - 2) + "s |%n", centerText(title, WIDTH - 2));
        System.out.println(border());

        for (String line : lines) {
            String text = line == null ? "" : line;
            if (text.length() > WIDTH - 4) {
                text = text.substring(0, WIDTH - 7) + "...";
            }
            System.out.printf("| %-" + (WIDTH - 2) + "s |%n", text);
        }

        System.out.println(border());
    }

    public static void showTable(String title, List<String> rows) {
        showPanel(title, rows);
    }

    public static void showSuccess(String message) {
        showAlert("SUCCESS", message);
    }

    public static void showInfo(String message) {
        showAlert("INFO", message);
    }

    public static void showWarning(String message) {
        showAlert("WARNING", message);
    }

    public static void showError(String message) {
        showAlert("ERROR", message);
    }

    public static void showAlert(String type, String message) {
        System.out.println();
        System.out.println(border());
        System.out.printf("| %-" + (WIDTH - 2) + "s |%n", centerText("[" + type + "]", WIDTH - 2));
        System.out.println(border());
        List<String> lines = wrapText(message, WIDTH - 4);
        for (String line : lines) {
            System.out.printf("| %-" + (WIDTH - 2) + "s |%n", line);
        }
        System.out.println(border());
    }

    public static String prompt(String label, Scanner scanner) {
        System.out.print(label + ": ");
        return scanner.nextLine();
    }

    private static String border() {
        return "+" + "-".repeat(WIDTH) + "+";
    }

    private static String centerText(String text, int width) {
        if (text.length() >= width) return text.substring(0, width);
        int left = (width - text.length()) / 2;
        int right = width - text.length() - left;
        return " ".repeat(left) + text + " ".repeat(right);
    }

    private static List<String> wrapText(String message, int maxLen) {
        List<String> lines = new ArrayList<>();
        if (message == null || message.isBlank()) {
            lines.add("");
            return lines;
        }

        String[] words = message.split(" ");
        StringBuilder current = new StringBuilder();
        for (String word : words) {
            if (current.length() + word.length() + 1 <= maxLen) {
                if (current.length() > 0) current.append(' ');
                current.append(word);
            } else {
                lines.add(current.toString());
                current = new StringBuilder(word);
            }
        }
        if (!current.isEmpty()) {
            lines.add(current.toString());
        }
        return lines;
    }
}
