const state = {
  selectedAction: 'overview',
  members: [],
  books: [],
  loans: [],
  reservations: [],
  notifications: []
};

const today = () => new Date();

const formatDate = (date) => {
  if (!date) return '—';
  const d = new Date(date);
  return d.toISOString().split('T')[0];
};

const cloneSampleData = () => {
  return {
    members: [
      { id: 'M001', name: 'Aarav', email: 'aarav@example.com', type: 'Student', borrowed: [] },
      { id: 'M002', name: 'Dr. Meera', email: 'meera@example.com', type: 'Faculty', borrowed: [] },
      { id: 'M003', name: 'Riya', email: 'riya@example.com', type: 'Student', borrowed: [] }
    ],
    books: [
      { id: 'B101', title: 'Java Programming', author: 'Herbert Schildt', category: 'Programming', totalCopies: 3, availableCopies: 3 },
      { id: 'B102', title: 'Data Structures', author: 'Mark Allen Weiss', category: 'Computer Science', totalCopies: 1, availableCopies: 1 },
      { id: 'B103', title: 'Database Systems', author: 'Raghu Ramakrishnan', category: 'Database', totalCopies: 2, availableCopies: 2 },
      { id: 'B104', title: 'Computer Networks', author: 'Andrew S. Tanenbaum', category: 'Networking', totalCopies: 2, availableCopies: 2 },
      { id: 'B105', title: 'Operating Systems', author: 'Silberschatz', category: 'Systems', totalCopies: 2, availableCopies: 2 }
    ],
    loans: [],
    reservations: [],
    notifications: []
  };
};

const resetData = () => {
  const demo = cloneSampleData();
  state.members = demo.members;
  state.books = demo.books;
  state.loans = demo.loans;
  state.reservations = demo.reservations;
  state.notifications = demo.notifications;
  state.selectedAction = 'overview';
  render();
  addResult('info', 'Demo data reset successfully.');
};

const getMemberById = (memberId) => state.members.find((member) => member.id === memberId);
const getBookById = (bookId) => state.books.find((book) => book.id === bookId);

const addResult = (type, message) => {
  const entry = document.createElement('div');
  entry.className = `result-box ${type}`;
  entry.textContent = message;
  const results = document.getElementById('resultsContainer');
  results.prepend(entry);
};

const buildStats = () => {
  const totalBooks = state.books.length;
  const totalCopies = state.books.reduce((sum, book) => sum + book.totalCopies, 0);
  const availableCopies = state.books.reduce((sum, book) => sum + book.availableCopies, 0);
  const activeLoans = state.loans.length;
  const reservations = state.reservations.length;

  return [
    { label: 'Books', value: totalBooks },
    { label: 'Copies', value: totalCopies },
    { label: 'Available', value: availableCopies },
    { label: 'Active loans', value: activeLoans },
    { label: 'Reservations', value: reservations },
    { label: 'Members', value: state.members.length }
  ];
};

const renderStats = () => {
  const statsGrid = document.getElementById('statsGrid');
  statsGrid.innerHTML = buildStats().map((stat) => `
    <div class="stat-card">
      <div class="label">${stat.label}</div>
      <div class="value">${stat.value}</div>
    </div>
  `).join('');
};

const renderOverview = () => {
  const rows = [
    ['Library status', 'Operations dashboard is active'],
    ['Available books', `${state.books.filter((b) => b.availableCopies > 0).length}`],
    ['Borrowed titles', `${state.loans.length}`],
    ['Waitlist entries', `${state.reservations.length}`],
    ['Members registered', `${state.members.length}`]
  ];

  const table = `
    <table class="list-table">
      <thead>
        <tr>
          <th>Metric</th>
          <th>Value</th>
        </tr>
      </thead>
      <tbody>
        ${rows.map(([key, value]) => `<tr><td>${key}</td><td>${value}</td></tr>`).join('')}
      </tbody>
    </table>
  `;

  document.getElementById('resultsContainer').innerHTML = table;
};

const renderInventory = () => {
  const rows = state.books.map((book) => `
    <tr>
      <td>${book.id}</td>
      <td>${book.title}</td>
      <td>${book.author}</td>
      <td>${book.category}</td>
      <td>${book.availableCopies}/${book.totalCopies}</td>
    </tr>
  `);

  document.getElementById('resultsContainer').innerHTML = rows.length
    ? `
      <table class="list-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Category</th>
            <th>Available</th>
          </tr>
        </thead>
        <tbody>${rows.join('')}</tbody>
      </table>
    `
    : '<div class="empty-state">No books available.</div>';
};

const renderMembers = () => {
  const rows = state.members.map((member) => `
    <tr>
      <td>${member.id}</td>
      <td>${member.name}</td>
      <td>${member.type}</td>
      <td>${member.borrowed.length}</td>
    </tr>
  `);

  document.getElementById('resultsContainer').innerHTML = rows.length
    ? `
      <table class="list-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Type</th>
            <th>Books loaned</th>
          </tr>
        </thead>
        <tbody>${rows.join('')}</tbody>
      </table>
    `
    : '<div class="empty-state">No members registered.</div>';
};

const renderCirculation = () => {
  const rows = state.loans.map((loan) => `
    <tr>
      <td>${loan.memberId}</td>
      <td>${loan.bookId}</td>
      <td>${formatDate(loan.issueDate)}</td>
      <td>${formatDate(loan.dueDate)}</td>
      <td>${loan.returnDate ? 'Returned' : 'Active'}</td>
    </tr>
  `);

  document.getElementById('resultsContainer').innerHTML = rows.length
    ? `
      <table class="list-table">
        <thead>
          <tr>
            <th>Member</th>
            <th>Book</th>
            <th>Issued</th>
            <th>Due</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>${rows.join('')}</tbody>
      </table>
    `
    : '<div class="empty-state">No circulation records.</div>';
};

const renderUtilization = () => {
  const rows = state.books.map((book) => {
    const utilization = ((book.totalCopies - book.availableCopies) / book.totalCopies) * 100;
    return `
      <tr>
        <td>${book.id}</td>
        <td>${book.title}</td>
        <td>${utilization.toFixed(1)}%</td>
      </tr>
    `;
  });

  document.getElementById('resultsContainer').innerHTML = `
    <table class="list-table">
      <thead>
        <tr>
          <th>Book</th>
          <th>Title</th>
          <th>Utilization</th>
        </tr>
      </thead>
      <tbody>${rows.join('')}</tbody>
    </table>
  `;
};

const renderReservations = () => {
  const rows = state.reservations.map((reservation) => `
    <tr>
      <td>${reservation.id}</td>
      <td>${reservation.memberId}</td>
      <td>${reservation.bookId}</td>
      <td>${formatDate(reservation.date)}</td>
    </tr>
  `);

  document.getElementById('resultsContainer').innerHTML = rows.length
    ? `
      <table class="list-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Member</th>
            <th>Book</th>
            <th>Queued</th>
          </tr>
        </thead>
        <tbody>${rows.join('')}</tbody>
      </table>
    `
    : '<div class="empty-state">No active reservations.</div>';
};

const renderSearchResults = (keyword) => {
  const q = keyword.trim().toLowerCase();
  if (!q) {
    document.getElementById('resultsContainer').innerHTML = '<div class="empty-state">Enter a keyword to search.</div>';
    return;
  }

  const matches = state.books.filter((book) => {
    const text = `${book.id} ${book.title} ${book.author} ${book.category}`.toLowerCase();
    return text.includes(q);
  });

  const rows = matches.map((book) => `
    <tr>
      <td>${book.id}</td>
      <td>${book.title}</td>
      <td>${book.author}</td>
      <td>${book.category}</td>
    </tr>
  `);

  document.getElementById('resultsContainer').innerHTML = rows.length
    ? `
      <table class="list-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Category</th>
          </tr>
        </thead>
        <tbody>${rows.join('')}</tbody>
      </table>
    `
    : '<div class="empty-state">No matching books found.</div>';
};

const formMap = {
  overview: () => '',
  registerMember: () => `
    <form id="memberForm">
      <div class="field">
        <label for="memberId">Member ID</label>
        <input id="memberId" name="memberId" required />
      </div>
      <div class="field">
        <label for="memberName">Name</label>
        <input id="memberName" name="memberName" required />
      </div>
      <div class="field">
        <label for="memberEmail">Email</label>
        <input id="memberEmail" name="memberEmail" type="email" required />
      </div>
      <div class="field">
        <label for="memberType">Type</label>
        <select id="memberType" name="memberType">
          <option value="Student">Student</option>
          <option value="Faculty">Faculty</option>
        </select>
      </div>
      <button class="primary-btn" type="submit">Register member</button>
    </form>
  `,
  addBook: () => `
    <form id="bookForm">
      <div class="field">
        <label for="bookId">Book ID</label>
        <input id="bookId" required />
      </div>
      <div class="field">
        <label for="bookTitle">Title</label>
        <input id="bookTitle" required />
      </div>
      <div class="field">
        <label for="bookAuthor">Author</label>
        <input id="bookAuthor" required />
      </div>
      <div class="field">
        <label for="bookCategory">Category</label>
        <input id="bookCategory" required />
      </div>
      <div class="field">
        <label for="bookCopies">Total copies</label>
        <input id="bookCopies" type="number" min="1" value="1" required />
      </div>
      <button class="primary-btn" type="submit">Add book</button>
    </form>
  `,
  issueBook: () => `
    <form id="issueForm">
      <div class="field">
        <label for="issueMemberId">Member ID</label>
        <input id="issueMemberId" required />
      </div>
      <div class="field">
        <label for="issueBookId">Book ID</label>
        <input id="issueBookId" required />
      </div>
      <button class="primary-btn" type="submit">Issue book</button>
    </form>
  `,
  returnBook: () => `
    <form id="returnForm">
      <div class="field">
        <label for="returnMemberId">Member ID</label>
        <input id="returnMemberId" required />
      </div>
      <div class="field">
        <label for="returnBookId">Book ID</label>
        <input id="returnBookId" required />
      </div>
      <div class="field">
        <label for="returnDate">Return date</label>
        <input id="returnDate" type="date" required />
      </div>
      <button class="primary-btn" type="submit">Return book</button>
    </form>
  `,
  reserveBook: () => `
    <form id="reserveForm">
      <div class="field">
        <label for="reserveMemberId">Member ID</label>
        <input id="reserveMemberId" required />
      </div>
      <div class="field">
        <label for="reserveBookId">Book ID</label>
        <input id="reserveBookId" required />
      </div>
      <button class="primary-btn" type="submit">Reserve</button>
    </form>
  `,
  searchBooks: () => `
    <form id="searchForm">
      <div class="field">
        <label for="searchKeyword">Keyword</label>
        <input id="searchKeyword" placeholder="Java, author, category, or book ID" required />
      </div>
      <button class="primary-btn" type="submit">Search catalog</button>
    </form>
  `,
  inventory: () => '',
  members: () => '',
  circulation: () => '',
  utilization: () => '',
  reservations: () => ''
};

const renderForm = () => {
  const panel = document.getElementById('formPanel');
  const html = formMap[state.selectedAction]?.() || '';
  if (!html) {
    panel.innerHTML = '<div class="empty-state">Choose an action from the sidebar.</div>';
    return;
  }

  panel.innerHTML = `
    <div class="panel-header">
      <h3>${document.getElementById('panelTitle').textContent}</h3>
    </div>
    <div style="padding: 18px 20px 20px;">${html}</div>
  `;

  bindFormHandlers();
};

const bindFormHandlers = () => {
  const memberForm = document.getElementById('memberForm');
  if (memberForm) {
    memberForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const id = document.getElementById('memberId').value.trim();
      const name = document.getElementById('memberName').value.trim();
      const email = document.getElementById('memberEmail').value.trim();
      const type = document.getElementById('memberType').value;

      if (!id || !name || !email) {
        addResult('error', 'Member ID, name and email are required.');
        return;
      }

      const exists = state.members.some((member) => member.id === id);
      if (exists) {
        addResult('error', 'Member ID already exists.');
        return;
      }

      state.members.push({ id, name, email, type, borrowed: [] });
      addResult('success', `Member ${name} registered successfully.`);
      render();
    });
  }

  const bookForm = document.getElementById('bookForm');
  if (bookForm) {
    bookForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const id = document.getElementById('bookId').value.trim();
      const title = document.getElementById('bookTitle').value.trim();
      const author = document.getElementById('bookAuthor').value.trim();
      const category = document.getElementById('bookCategory').value.trim();
      const totalCopies = Number(document.getElementById('bookCopies').value);

      if (!id || !title || !author || !category || totalCopies <= 0) {
        addResult('error', 'All book fields are required and copies must be positive.');
        return;
      }

      const exists = state.books.some((book) => book.id === id);
      if (exists) {
        addResult('error', 'Book ID already exists.');
        return;
      }

      state.books.push({ id, title, author, category, totalCopies, availableCopies: totalCopies });
      addResult('success', `Book ${title} added successfully.`);
      render();
    });
  }

  const issueForm = document.getElementById('issueForm');
  if (issueForm) {
    issueForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const memberId = document.getElementById('issueMemberId').value.trim();
      const bookId = document.getElementById('issueBookId').value.trim();
      const member = getMemberById(memberId);
      const book = getBookById(bookId);

      if (!member) {
        addResult('error', 'Invalid member ID.');
        return;
      }
      if (!book) {
        addResult('error', 'Book not found.');
        return;
      }
      if (member.borrowed.length >= (member.type === 'Faculty' ? 8 : 4)) {
        addResult('error', 'Borrowing limit reached for this member.');
        return;
      }
      if (book.availableCopies <= 0) {
        addResult('error', 'No available copy for this book.');
        return;
      }

      member.borrowed.push(bookId);
      book.availableCopies -= 1;
      state.loans.push({
        memberId,
        bookId,
        issueDate: new Date(),
        dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
        returnDate: null
      });

      addResult('success', `Book ${bookId} issued to ${memberId}. Due date: ${formatDate(new Date(Date.now() + 14 * 24 * 60 * 60 * 1000))}`);
      render();
    });
  }

  const returnForm = document.getElementById('returnForm');
  if (returnForm) {
    returnForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const memberId = document.getElementById('returnMemberId').value.trim();
      const bookId = document.getElementById('returnBookId').value.trim();
      const returnDate = new Date(document.getElementById('returnDate').value);
      const member = getMemberById(memberId);
      const book = getBookById(bookId);
      const loan = state.loans.find((item) => item.memberId === memberId && item.bookId === bookId && !item.returnDate);

      if (!member || !book) {
        addResult('error', 'Member or book not found.');
        return;
      }
      if (!loan) {
        addResult('error', 'No active loan found for this member and book.');
        return;
      }

      loan.returnDate = returnDate;
      book.availableCopies += 1;
      member.borrowed = member.borrowed.filter((id) => id !== bookId);

      const overdueDays = Math.max(0, Math.ceil((returnDate - new Date(loan.dueDate)) / (1000 * 60 * 60 * 24)));
      const fine = overdueDays * 2;
      addResult('success', `Book returned successfully. Fine: Rs. ${fine.toFixed(2)}`);
      render();
    });
  }

  const reserveForm = document.getElementById('reserveForm');
  if (reserveForm) {
    reserveForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const memberId = document.getElementById('reserveMemberId').value.trim();
      const bookId = document.getElementById('reserveBookId').value.trim();
      const member = getMemberById(memberId);
      const book = getBookById(bookId);

      if (!member) {
        addResult('error', 'Invalid member ID.');
        return;
      }
      if (!book) {
        addResult('error', 'Book not found.');
        return;
      }
      if (book.availableCopies > 0) {
        addResult('error', 'Book is available; no reservation needed.');
        return;
      }
      const dup = state.reservations.some((res) => res.memberId === memberId && res.bookId === bookId);
      if (dup) {
        addResult('error', 'Duplicate reservation is not allowed.');
        return;
      }

      state.reservations.push({ id: `R${Date.now()}`, memberId, bookId, date: new Date() });
      addResult('success', `Reservation added to waitlist for ${memberId}.`);
      render();
    });
  }

  const searchForm = document.getElementById('searchForm');
  if (searchForm) {
    searchForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const keyword = document.getElementById('searchKeyword').value;
      renderSearchResults(keyword);
    });
  }
};

const render = () => {
  renderStats();
  document.getElementById('panelTitle').textContent = {
    overview: 'Overview',
    registerMember: 'Register Member',
    addBook: 'Add Book',
    issueBook: 'Issue Book',
    returnBook: 'Return Book',
    reserveBook: 'Reserve Book',
    searchBooks: 'Search Books',
    inventory: 'Inventory',
    members: 'Members',
    circulation: 'Circulation',
    utilization: 'Utilization',
    reservations: 'Reservations'
  }[state.selectedAction] || 'Overview';

  const actions = {
    overview: renderOverview,
    inventory: renderInventory,
    members: renderMembers,
    circulation: renderCirculation,
    utilization: renderUtilization,
    reservations: renderReservations
  };

  if (actions[state.selectedAction]) {
    actions[state.selectedAction]();
  } else {
    document.getElementById('resultsContainer').innerHTML = '<div class="empty-state">Action started. Submit the form to see results.</div>';
  }

  renderForm();
  document.querySelectorAll('.nav-btn').forEach((button) => {
    button.classList.toggle('active', button.dataset.action === state.selectedAction);
  });
};

document.addEventListener('DOMContentLoaded', () => {
  resetData();

  document.querySelectorAll('.nav-btn').forEach((button) => {
    button.addEventListener('click', () => {
      state.selectedAction = button.dataset.action;
      render();
    });
  });

  document.getElementById('resetDataBtn').addEventListener('click', resetData);
  render();
});
